# Final project of Honors Full Stack -1. 
Shopping app made from MERN Stack.
# 
#
 PS: Admin Credentials  
#
Email : admin@gmail.com
Password : admin123
